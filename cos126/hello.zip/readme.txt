/*******************************************************************************
 *  Name:    
 *  NetID:   
 *  Precept: 
 ******************************************************************************/


COS 126 Assignment: Hello, World

Do you have a laptop that you can bring to precept?

What operating system do you use?

Which text editor are you using to edit this file? (We recommend IntelliJ!)

Have you taken part of COS 126 before?

Number of hours to complete this assignment:

/******************************************************************************
 ***   Some information to help your preceptor get to know you.             ***
 ******************************************************************************/

Nickname (i.e., what you prefer to be called in class):

Year:

AB/BSE:

Possible major(s) (if you know or have an idea):

Confidence level (0 = very afraid, 5 = very confident):

Do you have any previous programming experience?

Why are you interested in taking this course?

What are your other interests?


/******************************************************************************
 ***   Part of Assignment 0 is to fill out the brief questionnaire.         ***
 ***   Did you do this?                                                     ***
 ******************************************************************************/

Yes or no?


/******************************************************************************
 ***   Another part of Assignment 0 is to read the collaboration policy on  ***
 ***   the syllabus and get 100% on the Blackboard quiz. (You can re-take   ***
 ***   the Blackboard quiz as many times as you need to.) Did you do this?  ***
 ******************************************************************************/

Yes or no?



/******************************************************************************
 ***   Yet another part of Assignment 0 is to complete the Treasure Hunt    ***
 ***   on Blackboard. You are welcome to do this with a friend; if so       ***
 ***   state your friend's name here. Did you do this?                      ***
 ******************************************************************************/

Yes or no?



/******************************************************************************
 ***   When (date and time) are the four exams in this course?              ***
 ******************************************************************************/

Written Exam 1: 
Programming Exam 1:
Written Exam 2:
Programming Exam 2:


/******************************************************************************
 ***   Check your calendar. Do you have any potential scheduling conflicts  ***
 ***   with any of these dates? If so, what is/are the conflict?            ***
 ******************************************************************************/

Yes or no?



/******************************************************************************
 ***   Did you receive help from classmates, past COS 126 students, or      ***
 ***   anyone else? If so, please list their names. ("A Sunday lab TA"      ***
 ***   or "Office hours on Thursday" is ok if you don't know their name.)   ***
 ******************************************************************************/

Yes or no? 



/******************************************************************************
 ***   Did you encounter any serious problems? If yes, please describe.     ***
 ******************************************************************************/

Yes or no? 


/******************************************************************************
 ***   List any other comments here.                                        ***
 ******************************************************************************/
